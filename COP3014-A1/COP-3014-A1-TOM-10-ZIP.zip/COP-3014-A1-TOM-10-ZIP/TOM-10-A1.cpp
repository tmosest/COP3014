// *****************************************
// Tyler Moses
// Assignment 1
// *****************************************

#include <iostream>

int main()
{
    std::cout << "Hello World!\n";
    std::cout << "My name is Tyler Moses" << std::endl;
}
